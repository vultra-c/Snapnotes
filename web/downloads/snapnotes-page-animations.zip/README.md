# 页面转场动画（快应用 SCR_LOAD_ANIM 复刻）

根据本仓库 `unpacked/animations.json` 中固件逆向出的 **LVGL SCR_LOAD_ANIM** 转场参数，
在 Vela 快应用层用公开 CSS `animation`/`@keyframes` 复刻，已接入手环端「闪念小抄」全部 15 个页面。

## 固件参数 → 快应用实现

| 固件转场 | 用途 | 关键帧 | 时长 | 缓动 |
|---|---|---|---|---|
| OVER_LEFT  | 压栈进入（打开文件夹等） | `translateX(40px)` → `0`，`opacity 0` → `1` | 320ms | `cubic-bezier(0.2,0,0,1)` |
| OVER_RIGHT | 返回上一层 | `translateX(-40px)` → `0`，`opacity 0` → `1` | 320ms | `cubic-bezier(0.2,0,0,1)` |

Vela 约束（官方文档《动画样式》）：
- `@keyframes` 只支持 `opacity`/`transform`/`width`/`height`/`background-*`；`transition` 不支持 `transform`，必须走 `@keyframes`；
- 0% 和 100% 关键帧必须显式写出；
- `animation-name/duration/timing-function`（含 `cubic-bezier`）均受支持；无 `fill-mode`，动画结束后回落到基础态——因此 100% 帧与基础态保持一致即可无感。

## 实现方式（三个文件）

1. **`style.css-animations.css`**（并入 `src/common/style.css`）：声明两个 `@keyframes`。
2. **`pageAnim.js`**（新增 `src/common/utils/pageAnim.js`）：共享工具
   - `enterStyle` / `rightStyle`：内联动画样式串；
   - `markBack()`：在 `router.back()` 前调用，置位 `appState.returnAnim`；
   - `playReturn(page)`：在页面 `onShow()` 开头调用，消费标记并播放 OVER_RIGHT，380ms 后清空样式以便下次重新触发。
3. **`appState.js`**：新增 `returnAnim: ''` 标记。

每个页面接入 5 步：
```text
1. import pageAnim from '../../common/utils/pageAnim.js'
2. private: { animStyle: pageAnim.enterStyle, ... }
3. 根节点 style 绑定：style="flex-direction: column;{{animStyle}}"
4. 所有 router.back() 前：pageAnim.markBack()
5. onShow() 开头：pageAnim.playReturn(this)
```

## 覆盖范围

index / subfolder / reader / content / globalSettings / search / chat / import /
createFolder / deleteConfirm / push / addAction / pageJump / percentJump / readerSettings。

返回动画同时覆盖：返回箭头、硬件返回键（onBackPress，chat/import/search 本次补齐）、
右滑返回（onSwipe）、以及 deleteConfirm/push 等自动返回流程。

## 验证

- `aiot build` 通过（build success），关键帧已编译进 `build/pages/*/index.js` 的样式引擎数据；
- 已推送 `vultra-c/Snapnotes@main`（`99d1f8a`），GitHub Actions `Vela App Release` 构建成功；
- 完整改动见 `snapnotes-page-animations.patch`（`git apply` 可复用到其他 Vela 项目）。
